package com.cg.ui;

import java.util.Random;
import java.util.Scanner;

import javax.security.auth.login.AccountNotFoundException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entities.TransferDetails;
import com.cg.entities.UserDetails;
import com.cg.service.ServiceImpl;

public class Client {
	public int getOption(Scanner scanner) {
		try {
			int option = scanner.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public static void main(String[] args) throws AccountNotFoundException {
		int option;
		Scanner scanner = new Scanner(System.in);
		
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		ServiceImpl bankService =  context.getBean("bankService",ServiceImpl.class);
		
		UserDetails userDetails = new UserDetails();
		TransferDetails transferDetails = new TransferDetails();
		TransferDetails transferDetails_1 = new TransferDetails();
		
		do {
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\t\t\t\tXYZ BANK WALLET");
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\n1)Create Account...");
			System.out.println("2)Show Balance...");
			System.out.println("3)Deposit...");
			System.out.println("4)Withdraw...");
			System.out.println("5)Fund Transfer...");
			System.out.println("6)Print Transaction...");
			System.out.println("7)Exit...");
			System.out.println("Enter your option: ");
			option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter your name:");
				String name = bankService.validationName(scanner.next());
				System.out.println("Enter your mobile number:");
				long mblNo = bankService.validationMblNo(scanner.nextLong());
				Random r = new Random();// random method used for creating a random account number
				int accNo = r.nextInt(100000000);// limit
				System.out.println("Enter your initial amount: ");
				double balance = bankService.validationBal((scanner.nextDouble()));// balance which is greater than zero or not
				userDetails.setAccNo(accNo);
				userDetails.setName(name);
				userDetails.setMblNo(mblNo);
				userDetails.setBalance(balance);

				bankService.createAccount(userDetails);// passing the details to service class

				System.out.println("Account created....");
				System.out.println("Your name: " + name);
				System.out.println("Your mobile number: " + mblNo);
				System.out.println("Your new account number: " + accNo);
				System.out.println("Your initial balance: " + balance);
				break;
			case 2:
				try {
					System.out.println("Enter your account number: ");
					accNo = scanner.nextInt();
					userDetails = bankService.showBalance(accNo);
					System.out.println("Customer Name : " + userDetails.getName());
					System.out.println("Customer Current balance : " + userDetails.getBalance());
				} catch (Exception ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 3:
				try {
					System.out.println("Enter your account number: ");
					accNo = scanner.nextInt();
					System.out.println("Enter your deposit amount: ");
					balance = bankService.validationBal(scanner.nextDouble());// balance which is greater than zero or not
					
					double mainBalance = userDetails.getBalance() + balance;
					userDetails.setBalance(mainBalance);
					bankService.depositBalance(userDetails);// passing the arguments to service class

					transferDetails.setTransactionType("Deposit");
					transferDetails.setAccNo(accNo);
					transferDetails.setBalance(balance);
					bankService.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails);

					userDetails=bankService.showBalance(accNo);
					System.out.println("Deposited successfully...");
					System.out.println("Hello  " + userDetails.getName());
					System.out.println(
							"Your Account Balance after Depositing " + balance + " Rs is " + userDetails.getBalance());
					System.out.println("\n-------------------------------------------------------------\n");
				} catch (Exception ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 4:
				try {
					System.out.println("Enter the account number: ");
					accNo = scanner.nextInt();
					System.out.println("Enter your withdraw amount: ");
					balance = bankService.validationBal(scanner.nextDouble());// balance which is greater than zero or not

					double mainBalance = userDetails.getBalance() - balance;
					userDetails.setBalance(mainBalance);
					bankService.withdrawBalance(userDetails);// passing the arguments to service class

					transferDetails.setTransactionType("Withdraw");
					transferDetails.setAccNo(accNo);
					transferDetails.setBalance(balance);
					bankService.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails);

					userDetails=bankService.showBalance(accNo);// passing the arguments to service class
					System.out.println("Withdrawn completed....");
					System.out.println("Hello  " + userDetails.getName());
					System.out.println(
							"Your Account Balance after Depositing " + balance + " Rs is " + userDetails.getBalance());
					System.out.println("\n-------------------------------------------------------------\n");
				} catch (Exception ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 5:
				try {
					System.out.println("Enter your account number: ");
					accNo = scanner.nextInt();
					System.out.println("Enter the account number to transfer: ");
					int accNo1 = scanner.nextInt();
					System.out.println("Enter the transfer amount: ");
					balance = scanner.nextDouble();

					userDetails = bankService.showBalance(accNo);
					double mainBalance = userDetails.getBalance() - balance;
					userDetails.setBalance(mainBalance);
					bankService.withdrawBalance(userDetails);

					userDetails = bankService.showBalance(accNo1);
					double mainBalance_1 = userDetails.getBalance() + balance;
					userDetails.setBalance(mainBalance_1);
					bankService.depositBalance(userDetails);

					transferDetails.setTransactionType("Transferred to " + accNo1);
					transferDetails.setAccNo(accNo);
					transferDetails.setBalance(balance);
					bankService.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails);
					int a = transferDetails.getTransId();

					transferDetails.setTransId(a);
					transferDetails.setTransactionType("Transferred from " + accNo);
					transferDetails.setAccNo(accNo1);
					transferDetails.setBalance(balance);
					bankService.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails_1);

					userDetails=bankService.showBalance(accNo);
					System.out.println("\n");
					System.out.println("Transfer completed.....");
					System.out.println("Hello  " + userDetails.getName());
					System.out.println(
							"Your Account Remaining Balance after Transaction Rs is " + userDetails.getBalance());
					System.out.println("\n-------------------------------------------------------------\n");
				} catch (Exception ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 6:
				try {
					System.out.println("Enter the account number: ");
					accNo = scanner.nextInt();
					bankService.getTransaction(accNo);
				} catch (Exception ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 7:
				System.out.println("Thank for using our service!!!");
				System.out.println("Regards\nXYZ BANK WALLET...");
				System.exit(0);
				break;
			default:
				System.out.println("Thanks.....");
				break;
			}
		} while (option != 7);
		scanner.close();
	}
}
