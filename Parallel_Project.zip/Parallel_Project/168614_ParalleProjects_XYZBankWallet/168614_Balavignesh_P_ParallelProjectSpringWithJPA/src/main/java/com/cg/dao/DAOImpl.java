package com.cg.dao;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entities.TransferDetails;
import com.cg.entities.UserDetails;
@Repository("d")
@Transactional
public class DAOImpl implements IDAO {
	Random random=new Random();

	@PersistenceContext
	private EntityManager entityManager;
	
	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void createAccount(UserDetails userDetails) {
		entityManager.persist(userDetails);
	}

	public UserDetails showBalance(int accNo) {
		UserDetails userDetails = entityManager.find(UserDetails.class, accNo);
		return userDetails;
	}

	public void depositBalance(UserDetails userDetails) {
		/*userDetails=entityManager.find(UserDetails.class,accNo);
		double mainBalance=userDetails.getBalance();
		double addBalance=mainBalance+balance;
		userDetails.setBalance(addBalance);
		
		TransferDetails transferDetails=new TransferDetails();
		transferDetails.setBalance(balance);
		transferDetails.setTransactionType("Deposit");
		transferDetails.setTransId(random.nextInt(100000));
		transferDetails.setUserDetails(userDetails);
		
		entityManager.persist(transferDetails);		*/
		entityManager.merge(userDetails);
	}

	public void withdrawBalance(UserDetails userDetails) {
		/*UserDetails userDetails=entityManager.find(UserDetails.class,accNo);
		double mainBalance=userDetails.getBalance();
		double addBalance=mainBalance-balance;
		userDetails.setBalance(addBalance);
		
		TransferDetails transferDetails=new TransferDetails();
		transferDetails.setBalance(balance);
		transferDetails.setTransactionType("Deposit");
		transferDetails.setTransId(random.nextInt(100000));
		transferDetails.setUserDetails(userDetails);
		
		entityManager.persist(transferDetails);	*/	
		entityManager.merge(userDetails);
	}
	
	/*public void fundTransfer(int accNo, int accNo1, double balance) {
		UserDetails userDetails=entityManager.find(UserDetails.class,accNo);
		UserDetails userDetails_1=entityManager.find(UserDetails.class,accNo1);
		if(userDetails.getBalance()<=0)
		{
			throw new InSufficientBalanceException("Balance too low...");
		}
		else
		{
			double mainBalance=userDetails.getBalance();
			double mainBalance_1=userDetails_1.getBalance();
			double originalBalance=mainBalance-balance;
			double originalBalance_1=mainBalance_1+balance;
			
			userDetails.setBalance(originalBalance);
			TransferDetails transferDetails=new TransferDetails();
			transferDetails.setBalance(balance);
			transferDetails.setTransactionType("Fund transfer");
			transferDetails.setTransId(random.nextInt(100000));
			transferDetails.setUserDetails(userDetails);
			transferDetails.setFromAccount(accNo);
			entityManager.persist(transferDetails);
			
			userDetails.setBalance(originalBalance_1);
			TransferDetails transferDetails_1=new TransferDetails();
			transferDetails_1.setBalance(balance);
			transferDetails_1.setTransactionType("Fund transfer");
			transferDetails_1.setTransId(random.nextInt(100000));
			transferDetails_1.setUserDetails(userDetails_1);
			transferDetails_1.setFromAccount(accNo1);
			entityManager.persist(transferDetails_1);
			
		}
	}*/

	@SuppressWarnings("unchecked")
	public void getTransaction(int accNo) {
		Query query = entityManager.createQuery("select t from TransferDetails t where accNo=:taccNo");
		query.setParameter("taccNo", accNo);
		List<TransferDetails> list = query.getResultList();
		System.out.println("TransactionId		Account Id		TrasactionType		Amount");
		System.out.println("-----------------------------------------------------------------------------------------");
		for (TransferDetails transferDetails_3 : list) {
			System.out.println(transferDetails_3.getTransId() + "			" + transferDetails_3.getAccNo() + "			"
					+ transferDetails_3.getTransactionType() + "		" + transferDetails_3.getBalance());
		}
	}

	public void addTransferDetails(TransferDetails transferDetails) {
		entityManager.persist(transferDetails);
	}
}