package com.cg.exceptions;

@SuppressWarnings("serial")
public class InSufficientBalanceException extends RuntimeException {
	public InSufficientBalanceException(String msg)
	{
		super(msg);
	}
	public InSufficientBalanceException(String msg,Throwable ex)
	{
		super(msg,ex);
	}
}
