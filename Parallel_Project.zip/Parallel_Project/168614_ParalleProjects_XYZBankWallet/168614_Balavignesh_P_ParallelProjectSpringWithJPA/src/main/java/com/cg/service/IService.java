package com.cg.service;

import com.cg.entities.TransferDetails;
import com.cg.entities.UserDetails;

public interface IService {

	void createAccount(UserDetails userDetails);

	UserDetails showBalance(int accNo);
	
	void depositBalance(UserDetails userDetails);

	void withdrawBalance(UserDetails userDetails);
	
	//void fundTransfer(int accNo, int accNo1, double balance);

	void getTransaction(int accNo);

	double validationBal(double balance);

	String validationName(String name);

	long validationMblNo(long mblNo);

	public void addTransferDetails(TransferDetails transferDetails);

}
