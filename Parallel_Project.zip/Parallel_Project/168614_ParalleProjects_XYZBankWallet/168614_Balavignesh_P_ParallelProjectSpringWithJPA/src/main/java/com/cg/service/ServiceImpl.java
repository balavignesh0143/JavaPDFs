package com.cg.service;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IDAO;
import com.cg.entities.TransferDetails;
import com.cg.entities.UserDetails;
@Service("bankService")
public class ServiceImpl implements IService {
	Scanner scanner = new Scanner(System.in);
	@Autowired
	IDAO d;

	public IDAO getD() {
		return d;
	}

	public void setD(IDAO d) {
		this.d = d;
	}

	public void createAccount(UserDetails userDetails) {
		d.createAccount(userDetails);
	}

	public UserDetails showBalance(int accNo) {
		UserDetails userDetails = d.showBalance(accNo);
		return userDetails;
	}

	public void depositBalance(UserDetails userDetails) {
		d.depositBalance(userDetails);
	}

	public void withdrawBalance(UserDetails userDetails) {
		d.withdrawBalance(userDetails);
	}
	
	/*public void fundTransfer(int accNo, int accNo1, double balance) {
		d.fundTransfer(accNo,accNo1,balance);
	}*/

	public void getTransaction(int accNo) {
		d.getTransaction(accNo);
	}

	public void addTransferDetails(TransferDetails transferDetails) {
		d.addTransferDetails(transferDetails);
	}
	
	public double validationBal(double balance) {
		while (true) {
			if (balance <= 0) {
				System.out.println("Amount is lesser than zero...");
				System.out.println("Enter the amount again: ");
				balance = (long) scanner.nextDouble();
			} else {
				return balance;
			}
		}
	}

	public String validationName(String name) {
		if (name.matches("[A-Z][a-zA-Z]*")) {
			return name;
		} else {
			System.out.println("Enter valid name: ");
			return name = scanner.next();
		}
	}

	public long validationMblNo(long mblNo) {
		while (true) {
			if (String.valueOf(mblNo).length() == 10) {
				return mblNo;
			} else {
				System.out.println("Enter the valid mobile number: ");
				mblNo = scanner.nextLong();
			}
		}
	}

}