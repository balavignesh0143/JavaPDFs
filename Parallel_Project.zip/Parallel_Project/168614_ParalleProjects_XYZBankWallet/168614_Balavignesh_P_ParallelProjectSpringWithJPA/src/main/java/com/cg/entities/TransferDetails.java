package com.cg.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "transaction")
public class TransferDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int transId;
	private int accNo;
	private double balance;
	private String transactionType;

	
	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	@Override
	public String toString() {
		return "TransferDetails [transId=" + transId + ", accNo=" + accNo + ", balance=" + balance
				+ ", transactionType=" + transactionType + "]";
	}

	public TransferDetails(int transId, int accNo, double balance, String transactionType) {
		super();
		this.transId = transId;
		this.accNo = accNo;
		this.balance = balance;
		this.transactionType = transactionType;
	}

	public TransferDetails() {

	}

}