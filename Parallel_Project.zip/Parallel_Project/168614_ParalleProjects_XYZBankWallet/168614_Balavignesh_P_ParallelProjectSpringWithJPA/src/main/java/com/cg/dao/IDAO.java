package com.cg.dao;

import com.cg.entities.TransferDetails;
import com.cg.entities.UserDetails;

public interface IDAO {

	void createAccount(UserDetails userDetails);

	UserDetails showBalance(int accNo);

	void getTransaction(int accNo);

	void depositBalance(UserDetails userDetails);

	void addTransferDetails(TransferDetails transferDetails);

	//void fundTransfer(int accNo, int accNo1, double balance);

	void withdrawBalance(UserDetails userDetails);

}
