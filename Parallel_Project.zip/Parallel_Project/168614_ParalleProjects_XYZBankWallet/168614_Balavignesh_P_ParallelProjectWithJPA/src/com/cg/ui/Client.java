package com.cg.ui;

import java.sql.SQLException;
import java.util.Random;
import java.util.Scanner;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;
import com.cg.exceptions.AccountNotFoundException;
import com.cg.service.IService;
import com.cg.service.ServiceImpl;

public class Client {
	public int getOption(Scanner scanner) {
		try {
			int option = scanner.nextInt();
			return option;
		} catch (Throwable e) {
			e.printStackTrace();
			return -1;
		}
	}

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int option;
		Scanner scanner = new Scanner(System.in);
		IService s = new ServiceImpl();
		UserDetails userDetails=new UserDetails();
		TransferDetails transferDetails = new TransferDetails();
		TransferDetails transferDetails_1 = new TransferDetails();

		do {
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\t\t\t\tXYZ BANK WALLET");
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\n1)Create Account...");
			System.out.println("2)Show Balance...");
			System.out.println("3)Deposit...");
			System.out.println("4)Withdraw...");
			System.out.println("5)Fund Transfer...");
			System.out.println("6)Print Transaction...");
			System.out.println("7)Exit...");
			System.out.println("Enter your option: ");
			option = scanner.nextInt();
			switch (option) {
			case 1:
				System.out.println("Enter your name:");
				String name = s.validationName(scanner.next());
				System.out.println("Enter your mobile number:");
				long mblNo = s.validationMblNo(scanner.nextLong());
				Random r = new Random();// random method used for creating a random account number
				int accNo = r.nextInt(100000000);// limit
				System.out.println("Enter your initial amount: ");
				double balance = s.validationBal((scanner.nextDouble()));// balance which is greater than zero or not
				userDetails.setAccNo(accNo);
				userDetails.setName(name);
				userDetails.setMblNo(mblNo);
				userDetails.setBalance(balance);
				
				s.createAccount(userDetails);// passing the details to service class
				
				System.out.println("Account created....");
				System.out.println("Your name: " + name);
				System.out.println("Your mobile number: " + mblNo);
				System.out.println("Your new account number: " + accNo);
				System.out.println("Your initial balance: " + balance);
				break;
			case 2:
				try {
					System.out.println("Enter your account number: ");
					accNo = scanner.nextInt();
					userDetails= s.showBalance(accNo);
					System.out.println("Customer Name : "+userDetails.getName());
					System.out.println("Customer Current balance : " + userDetails.getBalance());
				} catch (AccountNotFoundException ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 3:
				try {
					System.out.println("Enter your account number: ");
					accNo = scanner.nextInt();
					System.out.println("Enter your deposit amount: ");
					balance = s.validationBal(scanner.nextDouble());// balance which is greater than zero or not
					double mainBalance=userDetails.getBalance()+balance;
					userDetails.setBalance(mainBalance);
					s.depositBalance(userDetails);// passing the arguments to service class
					
					transferDetails.setTransactionType("Deposit");
					transferDetails.setAccNo(accNo);
					transferDetails.setBalance(balance);
					s.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails);
					
					userDetails=s.showBalance(accNo);
					System.out.println("Deposited successfully...");
					System.out.println("Hello  "+userDetails.getName());
					System.out.println("Your Account Balance after Depositing "+balance+" Rs is "+userDetails.getBalance());
					System.out.println("\n-------------------------------------------------------------\n");
				} catch (AccountNotFoundException ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 4:
				try {
					System.out.println("Enter the account number: ");
					accNo = scanner.nextInt();
					System.out.println("Enter your withdraw amount: ");
					balance = s.validationBal(scanner.nextDouble());// balance which is greater than zero or not
					
					double mainBalance=userDetails.getBalance()-balance;
					userDetails.setBalance(mainBalance);
					s.withdrawBalance(userDetails);// passing the arguments to service class
					
					transferDetails.setTransactionType("Withdraw");
					transferDetails.setAccNo(accNo);
					transferDetails.setBalance(balance);
					s.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails);
					
					userDetails=s.showBalance(accNo);
					
					userDetails=s.showBalance(accNo);// passing the arguments to service class
					System.out.println("Withdrawn completed....");
					System.out.println("Hello  "+userDetails.getName());
					System.out.println("Your Account Balance after Depositing "+balance+" Rs is "+userDetails.getBalance());
					System.out.println("\n-------------------------------------------------------------\n");
				} catch (AccountNotFoundException ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 5:
				try {
					System.out.println("Enter your account number: ");
					accNo = scanner.nextInt();
					System.out.println("Enter the account number to transfer: ");
					int accNo1 = scanner.nextInt();
					System.out.println("Enter the transfer amount: ");
					balance = scanner.nextDouble();
					
					double mainBalance=userDetails.getBalance()-balance;
					userDetails.setBalance(mainBalance);
					s.depositBalance(userDetails);
					
					userDetails=s.showBalance(accNo1);
					double mainBalance_1=userDetails.getBalance()+balance;
					userDetails.setBalance(mainBalance_1);
					s.depositBalance(userDetails);
					
					transferDetails.setTransactionType("Transferred to "+accNo1);
					transferDetails.setAccNo(accNo);
					transferDetails.setBalance(balance);
					s.addTransferDetails(transferDetails);
					userDetails.setTransferDetails(transferDetails);
					int a=transferDetails.getTransId();
					
					transferDetails_1.setTransId(a);
					transferDetails_1.setTransactionType("Transferred from "+accNo);
					transferDetails_1.setAccNo(accNo1);
					transferDetails_1.setBalance(balance);
					s.addTransferDetails(transferDetails_1);
					userDetails.setTransferDetails(transferDetails_1);
					
					
					userDetails=s.showBalance(accNo);
					System.out.println("\n");
					System.out.println("Transfer completed.....");
					System.out.println("Hello  "+userDetails.getName());
					System.out.println("Your Account Remaining Balance after Transaction Rs is "+userDetails.getBalance());
					System.out.println("\n-------------------------------------------------------------\n");
				} catch (AccountNotFoundException ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 6:
				try {
					System.out.println("Enter the account number: ");
					accNo = scanner.nextInt();
					s.getTransaction(accNo);
				} catch (AccountNotFoundException ex) {
					throw new AccountNotFoundException("Invalid account number...");
				}
				break;
			case 7:
				System.out.println("Thank for using our service!!!");
				System.out.println("Regards\nXYZ BANK WALLET...");
				System.exit(0);
				break;
			default:
				System.out.println("Thanks.....");
				break;
			}
		} while (option != 7);
		scanner.close();
	}
}
