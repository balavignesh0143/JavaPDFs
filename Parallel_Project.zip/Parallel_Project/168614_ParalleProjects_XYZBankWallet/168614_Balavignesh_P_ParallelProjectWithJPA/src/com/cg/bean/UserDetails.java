package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "bankWallet")
public class UserDetails {
	@Id
	@Column(length = 20)
	private int accNo;
	@Column(length = 20)
	private String name;
	@Column(length = 20)
	private long mblNo;
	@Column(length = 20)
	private double balance;

	@OneToOne
	private TransferDetails transferDetails;

	public int getAccNo() {
		return accNo;
	}

	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getMblNo() {
		return mblNo;
	}

	public void setMblNo(long mblNo) {
		this.mblNo = mblNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public TransferDetails getTransferDetails() {
		return transferDetails;
	}

	public void setTransferDetails(TransferDetails transferDetails) {
		this.transferDetails = transferDetails;
	}

}
