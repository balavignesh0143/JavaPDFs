package com.cg.dao;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.bean.UserDetails;


public class JUnit {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	DAOImpl dao = new DAOImpl();

	@Test
	public void getBalanceById() throws ClassNotFoundException, SQLException {
		UserDetails userDetails=dao.showBalance(96664741);
		// fail("Not yet implemented");
		// assertNotNull(bean);
		assertTrue(1000 == userDetails.getBalance());//Junit pass
	}
}
