package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;

public class DAOImpl implements IDAO {
	UserDetails userDetails = new UserDetails();

	EntityManager entityManager = DB.getEntityManager();

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void createAccount(UserDetails userDetails) {
		entityManager.persist(userDetails);
	}

	@Override
	public UserDetails showBalance(int accNo) {
		UserDetails userDetails = entityManager.find(UserDetails.class, accNo);
		return userDetails;
	}

	@Override
	public void depositBalance(UserDetails userDetails) {
		entityManager.merge(userDetails);
	}

	@Override
	public void withdrawBalance(UserDetails userDetails) {
		entityManager.merge(userDetails);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void getTransaction(int accNo) {
		Query query = entityManager.createQuery("select t from TransferDetails t where accNo=:taccNo");
		query.setParameter("taccNo", accNo);
		List<TransferDetails> list = query.getResultList();
		System.out.println("TransactionId		Account Id		TrasactionType		Amount");
		System.out.println("-----------------------------------------------------------------------------------------");
		for (TransferDetails transferDetails_3 : list) {
			System.out.println(transferDetails_3.getTransId() + "			" + transferDetails_3.getAccNo() + "			"
					+ transferDetails_3.getTransactionType() + "		" + transferDetails_3.getBalance());
		}
	}

	@Override
	public void addTransferDetails(TransferDetails transferDetails) {
		entityManager.persist(transferDetails);
	}

}