package com.cg.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.bean.TransactionDetails;
import com.cg.bean.UserDetails;
import com.cg.dao.Store;

public class Calculation implements CalculationInter {

	Scanner sc = new Scanner(System.in);
	Store s = new Store();

	@Override
	public void createAccount(UserDetails userDetails, TransactionDetails transfer)
			throws SQLException, ClassNotFoundException {
		s.createAccount(userDetails, transfer);
	}

	@Override
	public double showBalance(int accNo) throws ClassNotFoundException, SQLException {
		return s.showBalance(accNo);
	}

	@Override
	public double depositBalance(int accNo, double balance, TransactionDetails transfer)
			throws ClassNotFoundException, SQLException {
		return s.depositBalance(accNo, balance, transfer);
	}

	@Override
	public double withdrawBalance(int accNo, double balance, TransactionDetails transfer)
			throws ClassNotFoundException, SQLException {
		return s.withdrawBalance(accNo, balance, transfer);
	}

	@Override
	public double fundTransfer(int accNo, int accNo1, double balance, TransactionDetails transfer_1,
			TransactionDetails transfer_2) throws ClassNotFoundException, SQLException {
		return s.fundTransfer(accNo, accNo1, balance, transfer_1, transfer_2);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ArrayList printTransaction(int accNo) throws ClassNotFoundException, SQLException {
		return s.printTransaction(accNo);
	}

	@Override
	public double validationBal(double balance) {
		while (true) {
			if (balance <= 0) {
				System.out.println("Amount is lesser than zero...");
				System.out.println("Enter the amount again: ");
				balance = (long) sc.nextDouble();
			} else {
				return balance;
			}
		}
	}

	@Override
	public String validationName(String name) {
		if (name.matches("[A-Z][a-zA-Z]*"))
			return name;
		else
			System.out.println("Enter valid name: ");
		return name = sc.next();
	}

	@Override
	public long validationMblNo(long mblNo) {
		while (true) {
			if (String.valueOf(mblNo).length() == 10) {
				return mblNo;
			} else {
				System.out.println("Enter the valid mobile number: ");
				mblNo = sc.nextLong();
			}
		}
	}

}
