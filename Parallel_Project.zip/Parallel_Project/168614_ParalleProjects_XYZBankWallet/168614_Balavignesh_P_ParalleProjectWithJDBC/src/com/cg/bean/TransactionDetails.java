package com.cg.bean;

public class TransactionDetails {
	private int transId;
	private int accNo;
	private String type;
	/**
	 * @return the transId
	 */
	public int getTransId() {
		return transId;
	}
	/**
	 * @param transId the transId to set
	 */
	public void setTransId(int transId) {
		this.transId = transId;
	}
	/**
	 * @return the accNo
	 */
	public int getAccNo() {
		return accNo;
	}
	/**
	 * @param accNo the accNo to set
	 */
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TransactionDetails [transId=" + transId + ", accNo=" + accNo + ", type=" + type + "]";
	}
	
	public TransactionDetails(int transId, int accNo, String type) {
		super();
		this.transId = transId;
		this.accNo = accNo;
		this.type = type;
	}
	
	public TransactionDetails() {
		// TODO Auto-generated constructor stub
	}
}
