package com.cg.dao;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

public class JUnit {

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	Store dao = new Store();

	@Test
	public void getBalanceById() throws ClassNotFoundException, SQLException {
		double balance = dao.showBalance(769154);
		// fail("Not yet implemented");
		// assertNotNull(bean);
		assertTrue(750 == balance);//Junit pass
	}
}
