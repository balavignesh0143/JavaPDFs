package com.cg.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bean.TransactionDetails;
import com.cg.bean.UserDetails;

public interface StoreInter {

	void createAccount(UserDetails userDetails, TransactionDetails transfer)
			throws SQLException, ClassNotFoundException;

	double showBalance(int accNo) throws ClassNotFoundException, SQLException;

	double depositBalance(int accNo, double balance, TransactionDetails transfer)
			throws ClassNotFoundException, SQLException;

	double withdrawBalance(int accNo, double balance, TransactionDetails transfer)
			throws ClassNotFoundException, SQLException;

	double fundTransfer(int accNo, int accNo1, double balance, TransactionDetails transfer_1,
			TransactionDetails transfer_2) throws ClassNotFoundException, SQLException;

	@SuppressWarnings("rawtypes")
	ArrayList printTransaction(int accNo) throws ClassNotFoundException, SQLException;

}
