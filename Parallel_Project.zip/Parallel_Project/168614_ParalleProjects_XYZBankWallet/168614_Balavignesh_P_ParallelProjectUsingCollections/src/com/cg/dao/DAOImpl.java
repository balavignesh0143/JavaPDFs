package com.cg.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;
import com.cg.exception.AccountNotFoundException;
import com.cg.exception.InSufficientFundsException;

public class DAOImpl implements IDAO {

	UserDetails userDetails;
	TransferDetails transferDetails;

	HashMap<Long, UserDetails> hashMap = new HashMap<Long, UserDetails>();
	HashMap<TransferDetails, Long> hashMap_1 = new HashMap<TransferDetails, Long>();

	public void addDetails(UserDetails userDetails) {
		this.userDetails = userDetails;
		hashMap.put(userDetails.getAccNo(), userDetails);
		System.out.println(hashMap);
	}

	public void transferDetails(TransferDetails transferDetails) {
		this.transferDetails = transferDetails;
		System.out.println(hashMap_1);
	}

	public HashMap<Long, UserDetails> hashMap() {
		return hashMap;
	}

	public HashMap<TransferDetails, Long> hashMap_1() {
		return hashMap_1;
	}

	public void createAccount(UserDetails userDetails) {
		hashMap.put(userDetails.getAccNo(), userDetails);
		userDetails = (UserDetails) hashMap.get(userDetails.getAccNo());
	}

	public double showBalance(long accNo) {
		userDetails = (UserDetails) hashMap.get(accNo);
		if (userDetails == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			double bal = userDetails.getBalance();
			return bal;
		}
	}

	public double depositBalance(long accNo, double deposit) {
		userDetails = (UserDetails) hashMap.get(accNo);
		if (userDetails == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			double bal = userDetails.getBalance();
			double d = bal + deposit;
			userDetails.setBalance(d);
			hashMap.put(accNo, userDetails);
			TransferDetails transferDetails = new TransferDetails();
			transferDetails.setAccNoFrom(accNo);
			transferDetails.setTransferAmt(deposit);
			transferDetails.setTransType("Deposit");
			DateTimeFormatter dataTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
			LocalDateTime localDataTime = LocalDateTime.now();
			transferDetails.setDateOfTrans(dataTimeFormatter.format(localDataTime));
			transferDetails.setBalance(d);
			hashMap_1.put(transferDetails, (long) deposit);
			return d;
		}
	}

	public double withdrawBalance(long accNo, double withdraw) {
		userDetails = (UserDetails) hashMap.get(accNo);
		if (userDetails == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			double bal = userDetails.getBalance();
			if (bal < withdraw) {
				throw new InSufficientFundsException("Insufficient funds!!!");
			} else {
				double d = bal - withdraw;
				userDetails.setBalance(d);
				hashMap.put(accNo, userDetails);
				TransferDetails transferDetails = new TransferDetails();
				transferDetails.setAccNoFrom(accNo);
				transferDetails.setTransferAmt(withdraw);
				transferDetails.setTransType("Withdraw");
				DateTimeFormatter dataTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
				LocalDateTime localDataTime = LocalDateTime.now();
				transferDetails.setDateOfTrans(dataTimeFormatter.format(localDataTime));
				transferDetails.setBalance(d);
				hashMap_1.put(transferDetails, (long) withdraw);
				return d;
			}
		}
	}

	public double fundTransfer(long accNo, long accNo1, double balance) {
		userDetails = (UserDetails) hashMap.get(accNo);
		UserDetails userDetails_1 = (UserDetails) hashMap.get(accNo1);
		if (userDetails == null || userDetails_1 == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			double bal = userDetails.getBalance();
			userDetails = (UserDetails) hashMap.get(accNo1);
			double bal1 = userDetails.getBalance();
			bal = bal - balance;
			bal1 = bal1 + balance;
			userDetails.setBalance(bal);
			hashMap.put(accNo, userDetails);
			userDetails.setBalance(bal1);
			hashMap.put(accNo1, userDetails);
			TransferDetails transferDetails = new TransferDetails();
			transferDetails.setAccNoFrom(accNo);
			transferDetails.setAccNoTo(accNo1);
			transferDetails.setTransferAmt(balance);
			transferDetails.setTransId(1000);// dummy
			transferDetails.setBalance(bal);
			transferDetails.setTransType("Transfer");
			DateTimeFormatter dataTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
			LocalDateTime localDataTime = LocalDateTime.now();
			transferDetails.setDateOfTrans(dataTimeFormatter.format(localDataTime));
			hashMap_1.put(transferDetails, (long) balance);
			return bal;
		}
	}

	public List<TransferDetails> printTrans(long accNo) {
		userDetails = (UserDetails) hashMap.get(accNo);
		if (userDetails == null) {
			throw new AccountNotFoundException("Invalid account number...");
		} else {
			Set<TransferDetails> set = hashMap_1.keySet();
			ArrayList<TransferDetails> arrayList = new ArrayList<>(set);
			return arrayList;
		}
	}
}
