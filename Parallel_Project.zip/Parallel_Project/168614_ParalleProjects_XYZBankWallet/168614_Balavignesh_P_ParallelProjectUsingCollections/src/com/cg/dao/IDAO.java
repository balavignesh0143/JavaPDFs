package com.cg.dao;

import java.util.List;

import com.cg.bean.TransferDetails;
import com.cg.bean.UserDetails;

public interface IDAO {
	public void addDetails(UserDetails userDetails);

	public void transferDetails(TransferDetails transferDetails);

	public void createAccount(UserDetails ud);

	public double showBalance(long accNo);

	public double depositBalance(long accNo, double deposit);

	public double withdrawBalance(long accNo, double withdraw);

	public double fundTransfer(long accNo, long accNo1, double balance);

	public List<TransferDetails> printTrans(long accNo);
}
