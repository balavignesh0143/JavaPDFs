package com.cg.exception;

@SuppressWarnings("serial")
public class InSufficientFundsException extends RuntimeException {
	public InSufficientFundsException(String msg) {
		super(msg);
	}

	public InSufficientFundsException(String msg, Throwable ex) {
		super(msg, ex);
	}

}
