package com.capg.bank.service;

import java.util.ArrayList;

import com.capg.bank.bean.BankBean;
import com.capg.bank.dao.BankDaoImpl;

public class BankServiceImpl implements IBankService {
	BankDaoImpl bdi = new BankDaoImpl();
	@Override
	public BankBean addAccount(BankBean bean) {
		return bdi.addAccount(bean);
	}

	@Override
	public BankBean getAccountBalence(int account_id) {
		
		return bdi.getAccountBalence(account_id);
	}

	@Override
	public BankBean deposit(int account_id, double amount) {
		return bdi.deposit(account_id, amount);
	}

	@Override
	public BankBean withdraw(int account_id, double amount) {
		
		return bdi.withdraw(account_id, amount);
	}

	@Override
	public BankBean fundTransfer(int account_id1, int account_id2, double amount) {
			
		return bdi.fundTransfer(account_id1, account_id2, amount);
	}

	@SuppressWarnings("rawtypes")
	@Override
	public ArrayList printDetails(int account_id) {
		// TODO Auto-generated method stub
		return bdi.printDetails(account_id);
	}

}
