package com.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.service.BankService;
import com.service.BankServiceI;

public class BankUI {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner(System.in);
		BankServiceI service = new BankService();
		int incrementID = 1001;
		while (true) {
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("\t\t\t\tXYZ BANK WALLET");
			System.out.println(
					"*******************************************************************************************************");
			System.out.println("1)Create Account...");
			System.out.println("2)Show Balance...");
			System.out.println("3)Deposit...");
			System.out.println("4)Withdraw...");
			System.out.println("5)Fund Transfer...");
			System.out.println("6)Print Transaction...");
			System.out.println("7)Exit...");
			System.out.println("Enter your choice: ");
			int option = scanner.nextInt();

			switch (option) {
			case 1:
				System.out.println("Enter your name : ");
				String name = scanner.next();
				name += scanner.nextLine();
				while (!service.checkName(name)) {
					System.out.print("Enter your name : ");
					name = scanner.next();
					name += scanner.nextLine();
				}
				System.out.print("Enter your mobile number : ");
				long mobNo = scanner.nextLong();
				while (!service.checkM(mobNo)) {
					System.out.print("Enter your mobile number : ");
					mobNo = scanner.nextLong();
				}
				System.out.print("Enter your password :");
				String password = scanner.next();
				while (!service.checkP(password)) {
					System.out.print("Enter your password :");
					password = scanner.next();
				}
				String st = service.addAccount(name, mobNo, password);
				incrementID++;
				System.out.println(st+"\n");
				break;
			case 2:
				System.out.println("Enter your account number : ");
				long accNo = scanner.nextLong();
				if (service.checkAccNo(accNo)) {
					System.out.println("Enter your password : ");
					String pass = scanner.next();
					if (service.checkPass(pass, accNo)) {
						long bal = service.getBalance(accNo);
						System.out.println("Your current balance: Rs." + bal);
					}
				}
				break;
			case 3:
				System.out.println("Enter your account number : ");
				accNo = scanner.nextLong();
				if (service.checkAccNo(accNo)) {
					System.out.println("Enter your password : ");
					String pass = scanner.next();
					if (service.checkPass(pass, accNo)) {
						System.out.println("Enter your deposit amount: ");
						long bal1 = scanner.nextInt();
						long bal = service.getBalance(accNo) + bal1;
						service.setBalance(accNo, bal, "TransID : " + incrementID + "Amount credited  Rs." + bal1);
						incrementID++;
						System.out.println("Deposited amount Rs." + bal1);
						System.out.println("Available balance Rs." + service.getBalance(accNo));
					}
				}
				break;
			case 4:
				System.out.println("Enter your account number : ");
				accNo = scanner.nextLong();
				if (service.checkAccNo(accNo)) {
					System.out.println("Enter your password : ");
					String pass = scanner.next();
					if (service.checkPass(pass, accNo)) {
						System.out.println("Enter your withdraw amount: ");
						long bal1 = scanner.nextInt();
						long bal = service.getBalance(accNo) - bal1;
						service.setBalance(accNo, bal, "TransID: " + incrementID + " Amount debited Rs." + bal1);
						System.out.println("Withdrawn amount Rs." + bal1);
						System.out.println("Available balance Rs." + service.getBalance(accNo));
						incrementID++;
					}
				}
				break;
			case 5:
				System.out.println("Enter your account number : ");
				accNo = scanner.nextLong();
				if (service.checkAccNo(accNo)) {
					System.out.println("Enter your password : ");
					String pass = scanner.next();
					if (service.checkPass(pass, accNo)) {
						System.out.println("Enter the account number to be transfer: ");
						long accNo1 = scanner.nextLong();
						if (service.checkAccNo(accNo1)) {
							long bal = service.getBalance(accNo);
							long bal1 = service.getBalance(accNo1);

							System.out.println("Enter the amount to be transferred: ");
							long bal2 = scanner.nextInt();
							service.setBalance(accNo, bal - bal2, "TransactionID: " + incrementID + " Amount debited Rs." + bal2
									+ " to account number " + accNo1);
							service.setBalance(accNo1, bal1 + bal2, "TransactionID: " + incrementID + " Amount credited Rs." + bal2
									+ " from account number " + accNo);
							System.out.println("Amount transactions  Rs." + bal2);
							System.out.println("Available balance Rs." + service.getBalance(accNo));
							incrementID++;
						}
					}
				}
				break;
			case 6:
				System.out.println("Enter your account number: ");
				accNo = scanner.nextLong();
				if (service.checkAccNo(accNo)) {
					System.out.println("Enter your password: ");
					String pass = scanner.next();
					if (service.checkPass(pass, accNo)) {
						System.out.println("***************Transaction***************");
						String strn = service.getTransaction(accNo);
						System.out.println(strn);
						System.out.println("Available balance is Rs." + service.getBalance(accNo));
					}
				}
				break;
			case 7:
				System.out.println("Thanks for using our wallet...");
				System.exit(0);
				break;
			default:
				System.out.println("Enter valid option!!!");
				break;

			}
		}
	}
}