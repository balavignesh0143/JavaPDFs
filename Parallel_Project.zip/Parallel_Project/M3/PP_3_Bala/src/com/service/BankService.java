package com.service;

import com.bean.BankEntity;
import com.dao.BankDao;
import com.dao.BankDaoI;

class MyException extends Exception {
	private static final long serialVersionUID = 1L;
	String s1;

	MyException(String s) {
		s1 = s;
	}

	public String toString() {
		return (s1);
	}

}

public class BankService implements BankServiceI {
	BankDaoI dao = new BankDao();

	@SuppressWarnings("unused")
	@Override
	public boolean checkName(String name) {
		int len = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < len; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0] > 63 && ch[0] < 90) {
					return true;
				} else {
					throw new MyException("Invalid Name");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}
		}
		return false;
	}

	@Override
	public long getBalance(long accNo) {
		long acc = dao.getBalance(accNo);
		return acc;
	}

	@Override
	public String getTransaction(long accNo) {
		String str = dao.getTransaction(accNo);
		return str;
	}

	@Override
	public void setBalance(long accNo, long bal, String st) {
		dao.setBalance(accNo, bal, st);
	}

	@Override
	public String addAccount(String name, long mobile, String password) {
		BankEntity bb = new BankEntity(name, mobile, password, 1000,
				"Account created successfully\n Amount deposited Rs.1000");
		long accNo = dao.setData(bb);
		return "Thankyou " + name + "!!!,\nAccount created successfully.\nYour account number is " + accNo;
	}

	@Override
	public BankEntity getInfo(long accNo) {
		BankEntity bank = dao.getInfo(accNo);
		return bank;
	}

	@Override
	public boolean checkAccNo(long acc) {
		try {
			if (dao.checkAccNo(acc)) {
				return true;
			} else
				throw new MyException("Invalid account number...");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkPass(String st, long accNo) {
		try {
			if (dao.checkPassword(st, accNo)) {
				return true;
			} else
				throw new MyException("Invalid password...");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean checkM(long mob) {
		String s = Long.toString(mob);
		int n = s.length();
		try {
			if (n == 10) {
				return true;
			} else {
				throw new MyException("Invalid mobile number...");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

	@Override
	public boolean checkP(String password) {
		try {
			if (password.length() >= 6) {
				return true;
			} else {
				throw new MyException("Invalid password...(Password must should be six characters)");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

}
