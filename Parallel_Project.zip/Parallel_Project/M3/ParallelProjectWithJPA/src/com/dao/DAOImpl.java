package com.dao;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.bean.UserDetails;
import com.service.ServiceImpl;

public class DAOImpl implements IDAO {
	UserDetails details = new UserDetails();
	ServiceImpl service;
	EntityManager em;
	DB db = new DB();

	@Override
	public int createAccount(UserDetails details) {
		em = db.getConnection();
		em.getTransaction().begin();
		//System.out.println("dao");
		em.persist(details);
		em.getTransaction().commit();
		return details.getAccNo();
	}

	@Override
	public double showBalance(int accNo) {
		em = db.getConnection();
		em.getTransaction().begin();
		details = em.find(UserDetails.class, accNo);
		em.getTransaction().commit();
		return details.getBalance();
	}

	@Override
	public double depositBalance(int accNo, double balance,String tran) {
		em = db.getConnection();
		em.getTransaction().begin();
		details = em.find(UserDetails.class, accNo);
		if (details == null) {
			System.out.println("Invalid");
		} else {
			double originalBal = details.getBalance();
			double mainBal = originalBal + balance;
			Query query = em.createQuery("update UserDetails d set d.balance=:mainBal_1,d.tran=:tran_1 where d.accNo=:accNo_1");
			query.setParameter("mainBal_1", mainBal);
			query.setParameter("tran_1",tran);
			query.setParameter("accNo_1", accNo);
			query.executeUpdate();
		}
		em.getTransaction().commit();
		return details.getBalance();
	}

	@Override
	public double withdrawBalance(int accNo, double balance,String tran_1) {
		em = db.getConnection();
		em.getTransaction().begin();
		details = em.find(UserDetails.class, accNo);
		if (details == null) {
			System.out.println("Invalid");
		} else {
			double originalBal = details.getBalance();
			double mainBal = originalBal - balance;
			Query query_1 = em.createQuery("update UserDetails d set d.balance=:mainBal_2,d.tran=:tran_2 where d.accNo=:accNo_2");
			query_1.setParameter("mainBal_2", mainBal);
			query_1.setParameter("tran_2",tran_1);
			query_1.setParameter("accNo_2", accNo);
			query_1.executeUpdate();			
		}
		em.getTransaction().commit();
		return details.getBalance();
	}

	@Override
	public double fundTransfer(int accNo, int accNo1, double balance) {

		em = db.getConnection();
		em.getTransaction().begin();
		details = em.find(UserDetails.class, accNo);
		if (details == null) {
			System.out.println("Invalid");
		} else {
			double originalBal = details.getBalance();
			double mainBal = originalBal - balance;
			String tran_1="Amount of Rs."+balance+" was debited from your account";
			Query query_2 = em.createQuery("update UserDetails d set d.balance=:mainBal,d.tran=:trans_1 where d.accNo=:accNo");
			query_2.setParameter("mainBal", mainBal);
			query_2.setParameter("trans_1",tran_1);
			query_2.setParameter("accNo", accNo);
			query_2.executeUpdate();
			
			if (details == null) {
				System.out.println("Invalid");
			} else {
				details = em.find(UserDetails.class, accNo1);
				double originalBal_1 = details.getBalance();
				double mainBal_1 = originalBal_1 + balance;
				String tran_2="Amount of Rs."+balance+" was credited to your account";
				Query query_3 = em.createQuery("update UserDetails d set d.balance=:mainBal_1,d.tran=:tran_2 where d.accNo1=:accNo_1");
				query_3.setParameter("mainBal_1", mainBal_1);
				query_3.setParameter("tran_2",tran_2);
				query_3.setParameter("accNo_1", accNo1);
				query_3.executeUpdate();
			}
		}
		em.getTransaction().commit();
		return details.getBalance();
	}

	@Override
	public String getTransaction(int accNo) {
		em=db.getConnection();
		em.getTransaction().begin();
		details=em.find(UserDetails.class,accNo);
		String tran=details.getTran();
		System.out.println(tran);
		em.getTransaction().commit();
		return tran;
	}

}