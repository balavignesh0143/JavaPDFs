package com.dao;

import com.bean.UserDetails;

public interface IDAO {

	int createAccount(UserDetails ud);

	double showBalance(int accNo);

	double depositBalance(int accNo, double balance,String tran);

	double withdrawBalance(int accNo, double balance,String tran);

	double fundTransfer(int accNo, int accNo1, double balance);

	String getTransaction(int accNo);

}
